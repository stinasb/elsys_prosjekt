from django.apps import AppConfig


class PunktConfig(AppConfig):
    name = 'punkt'
